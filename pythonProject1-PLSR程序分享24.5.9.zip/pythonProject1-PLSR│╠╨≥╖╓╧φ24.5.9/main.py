import pandas as pd
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score


print('POWER BY QSK，不一定对，仅供参考，欢迎多交流，微信18031937628')
print('你好，我的微信是18031937628，加群以及互相交流都通过微信，加我的时候麻烦备注一下。我的研究方向是以近红外光谱进行土壤养分的回归预测（偏向深度学习）。微信群公告有哔站地址，有视频与对应的代码，代码在置顶评论的github上下载。')


# 读取Excel文件
excel_file = '示例数据集.xlsx'  # 替换为你的Excel文件名  hader=0为默认，默认第一行不参与计算;;;;hader=none为第一行也是数据，按照给出的格式来填写
df = pd.read_excel(excel_file)


df.columns = df.columns.astype(str)  #列 改成字符串类型 不然报warn
# 选择第二列到最后一列的所有列
data = df.iloc[:, :]        # iloc使用基于位置的索引，第一个冒号表示选择所有行，
print(data)                  #输出一下数据集
X = data.iloc[:, 1:]        # 选择除了第一列的所有列作为特征 X
Y = data.iloc[:, 0]          # 选择第一列作为标签 Y
# 划分数据集为训练集和测试集
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)



n_components=0
total_trainings =15     # 设置想要训练的次数（一般在50以下）  ，结合下一行代码，主成分会从0开始往上加，数量不超过特征总数的30%， 有报错考虑样本不够的问题，样本和特征都别太少


for training_round in range(total_trainings):  #循环多次训练，每次出一个r2的模型并保存，可以整晚跑代码了

    n_components=n_components+1
    # 创建PLSR对象
    plsraaa = PLSRegression(n_components)  # n_components为PLSR的成分数，一直在随着循环增加
    # 拟合（训练）模型
    plsraaa.fit(X_train, Y_train)
    # 预测测试集
    Y_pred = plsraaa.predict(X_test)
    # 计算R^2值
    r2 = r2_score(Y_test, Y_pred)

    print(f"当前主成分数{n_components}")
    print(f"Final R² Score: {r2:.4f}")
    print('*************************一轮结束**************************************')

